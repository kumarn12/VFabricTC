Version: 2.9.7.RELEASE
Build Date: 20140723180532

* Adds a JDBC resource that integrates with request diagnostics to report slow queries
* Adds a ThreadDiagnosticsValve at the Engine level to report slow running requests