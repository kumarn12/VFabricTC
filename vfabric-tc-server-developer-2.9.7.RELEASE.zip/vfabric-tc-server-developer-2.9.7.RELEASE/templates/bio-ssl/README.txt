Version: 2.9.7.RELEASE
Build Date: 20140723180532

* Adds a Blocking IO (BIO) connector for HTTPS
* Adds sample certificate and key files that can be used to test the SSL configuration