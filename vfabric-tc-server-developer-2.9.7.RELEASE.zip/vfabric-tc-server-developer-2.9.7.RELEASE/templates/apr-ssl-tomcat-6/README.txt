Version: 2.9.7.RELEASE
Build Date: 20140723180532

* Disable SSLv2 for APR/native (APR) connector by setting SSLProtocol to TLSv1
