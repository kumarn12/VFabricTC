Version: 2.9.7.RELEASE
Build Date: 20140723180532

* Adds asynchronous logging