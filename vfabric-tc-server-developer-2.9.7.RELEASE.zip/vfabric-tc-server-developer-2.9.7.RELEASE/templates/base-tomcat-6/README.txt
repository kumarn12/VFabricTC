Version: 2.9.7.RELEASE
Build Date: 20140723180532

* Adds Tomcat 6-specific ServerLifecycleListener
* Adds Tomcat 6-specific default catalina.policy to be used when starting with the -security option
* Adds Tomcat 6-specific JspServlet configuration
* Adds Tomcat 6-specific web-app declaration
