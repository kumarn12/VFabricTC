Version: 2.9.7.RELEASE
Build Date: 20140723180532

* Updates the JmxSocketListener to use SSL for all JMX communication
* Adds sample certificate and key files that can be used to test the SSL configuration