Version: 2.9.7.RELEASE
Build Date: 20140723180532

* Adds a Blocking IO (BIO) connector for HTTP